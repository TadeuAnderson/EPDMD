/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Rick
 */
public class Constantes {

    public class Operacao {

        public static final int opNothing = 0;
        public static final int opDestroy = 1;
        public static final int opMove = 2;
        public static final int opReenquadre = 3;
        public static final int opResize = 4;
        public static final int opReposicione = 5;
        public static final int opOrganizeLigacoes = 6;
        public static final int opRefresh = 7;
        public static final int opSubDestroy = 8;
    }

}
